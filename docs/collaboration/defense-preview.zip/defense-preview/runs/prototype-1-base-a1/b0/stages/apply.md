Completed the synthetic apply fixture.
