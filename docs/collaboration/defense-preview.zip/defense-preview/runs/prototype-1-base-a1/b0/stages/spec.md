Completed the synthetic spec fixture.
