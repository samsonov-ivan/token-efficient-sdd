Checked the marker in the lifecycle fixture.
VERIFY: PASS
