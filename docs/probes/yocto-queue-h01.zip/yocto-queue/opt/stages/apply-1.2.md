Published the generic return type and its tsd checks.
Documented empty queues and nondestructive access.
Tests: AVA and tsd.
