Created proposal, design, requirement scenarios and tasks.
