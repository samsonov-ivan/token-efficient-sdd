Implement only task 1.1: - [ ] 1.1 Implement the runtime method and cover queue transitions with AVA. REQ-QUEUE-01 SCN-QUEUE-01.1 SCN-QUEUE-01.2

Read the full change in openspec/changes/add-peek-last/, including proposal, specs, design and tasks.md.

Previous handoff (openspec/changes/add-peek-last/handoff.md):
No handoff has been recorded.

Implement only task 1.1. Return a 3–7 line handoff describing the implementation, public interfaces and tests. The orchestrator records task completion.