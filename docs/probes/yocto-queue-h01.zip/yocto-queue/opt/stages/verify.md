Inspected the completed change against both queue scenarios and the public API.
VERIFY: PASS
