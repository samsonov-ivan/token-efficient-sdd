Reviewed implementation, public types, tests, docs and the change specification.
VERDICT: ACCEPT
