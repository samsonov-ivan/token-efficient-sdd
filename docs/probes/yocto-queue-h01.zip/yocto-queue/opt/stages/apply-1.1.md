Implemented peekLast() and its AVA runtime test.
Reference: ce411efd-735d-4d6a-9a2e-c969317fc449
Next: declare the generic return type and document the method.
