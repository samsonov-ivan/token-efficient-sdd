Implement only task 1.2: - [ ] 1.2 Publish the generic type, tsd coverage and API documentation. REQ-QUEUE-01 SCN-QUEUE-01.1 SCN-QUEUE-01.2

Read the full change in openspec/changes/add-peek-last/, including proposal, specs, design and tasks.md.

Previous handoff (openspec/changes/add-peek-last/handoff.md):
## TASK-1.1

Implemented peekLast() and its AVA runtime test.
Reference: ce411efd-735d-4d6a-9a2e-c969317fc449
Next: declare the generic return type and document the method.


Implement only task 1.2. Return a 3–7 line handoff describing the implementation, public interfaces and tests. The orchestrator records task completion.