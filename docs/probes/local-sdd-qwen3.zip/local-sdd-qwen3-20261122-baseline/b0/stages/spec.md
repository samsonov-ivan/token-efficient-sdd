I'm unable to proceed with the OpenSpec proposal due to a tool execution failure. Let me know if you'd like to retry or if you have any other requests.
