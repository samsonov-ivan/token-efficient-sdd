# Spec Delta

## Purpose

Introduces conditional dequeue operations for dynamic queue processing, enabling flexible and safe handling of queue elements based on runtime predicates.

## ADDED Requirements

### Requirement: Queue can conditionally dequeue elements
The queue SHALL support a `dequeueIf(predicate)` method that removes the head of the queue if the predicate returns truthy.

#### Scenario: Successful conditional dequeue
- **WHEN** the predicate returns a truthy value on the head element
- **THEN** the head element is removed from the queue and `true` is returned

#### Scenario: Conditional dequeue with falsy predicate
- **WHEN** the predicate returns a falsy value on the head element
- **THEN** the head element remains in the queue and `false` is returned

#### Scenario: Conditional dequeue on empty queue
- **WHEN** the queue is empty
- **THEN** the method returns `false` without calling the predicate

### Requirement: Queue can drain while matching a predicate
The queue SHALL support a `drainWhile(predicate)` method that removes the longest prefix of elements matching the predicate.

#### Scenario: Successful drain while
- **WHEN** the predicate returns truthy on multiple consecutive elements
- **THEN** all matching elements are removed and the count of removed elements is returned

#### Scenario: Drain while with early rejection
- **WHEN** the predicate returns falsy on the first element
- **THEN** only the first element is retained and the count of removed elements is returned as zero

#### Scenario: Drain while on empty queue
- **WHEN** the queue is empty
- **THEN** the method returns zero without calling the predicate