# Design

## Context

The Queue class currently provides a standard FIFO API with methods for size, iteration, clear(), and drain(). This design extends the class to support conditional dequeue operations, enabling dynamic processing of queue elements based on runtime predicates without requiring full reprocessing.

## Goals / Non-Goals

**Goals:**
- Implement `dequeueIf(predicate)` to conditionally remove the head element based on a predicate function.
- Implement `drainWhile(predicate)` to remove the longest prefix of elements matching a predicate.
- Preserve all existing public FIFO API methods.
- Ensure methods handle edge cases (empty queue, undefined values, errors).

**Non-Goals:**
- Modify the underlying data structure of the queue (e.g., from array to linked list).
- Change the public API contract beyond the specified methods.
- Add new public methods beyond those defined in the requirements.
