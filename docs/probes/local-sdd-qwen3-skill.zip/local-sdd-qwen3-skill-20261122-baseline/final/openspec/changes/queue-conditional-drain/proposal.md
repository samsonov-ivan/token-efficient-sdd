# Proposal

## Why

Extend the Queue class to support conditional dequeue operations, enabling more flexible and safe handling of queue elements based on runtime predicates. This improves the system's ability to process elements dynamically without requiring full reprocessing or blocking.

## What Changes

- Add a new `dequeueIf(predicate)` method that removes the head of the queue if the predicate returns truthy.
- Add a new `drainWhile(predicate)` method that removes the longest prefix of elements matching the predicate.
- Preserve all existing public FIFO API methods: size, iteration, clear(), and drain().

## Capabilities

### New Capabilities
- `queue/conditional-dequeue`: Introduces conditional dequeue operations for dynamic queue processing.

## Impact

- Affected code: queue.mjs
- Affected tests: test/dequeue-if.test.mjs, test/drain-while.test.mjs
- No breaking changes to existing APIs.