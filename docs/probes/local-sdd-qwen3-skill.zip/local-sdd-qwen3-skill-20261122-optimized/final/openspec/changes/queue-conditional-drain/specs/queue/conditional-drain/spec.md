# Spec Delta

## Purpose

Introduces conditional dequeue and drain operations for flexible queue processing, enabling dynamic filtering and processing of queue elements based on runtime predicates.

## ADDED Requirements

### Requirement: Queue can conditionally dequeue elements
The queue SHALL support a `dequeueIf(predicate)` method that removes the head element if the provided predicate returns a truthy value.

#### Scenario: Successful conditional dequeue
- **WHEN** a predicate function returns true for the head element
- **THEN** the head element is removed from the queue and `true` is returned

#### Scenario: Conditional dequeue with falsy result
- **WHEN** a predicate function returns false for the head element
- **THEN** the head element remains in the queue and `false` is returned

#### Scenario: Empty queue with predicate
- **WHEN** the queue is empty and a predicate is provided
- **THEN** the method returns `false` without calling the predicate

### Requirement: Queue can drain while matching a predicate
The queue SHALL support a `drainWhile(predicate)` method that removes the longest prefix of elements matching the predicate and returns the count removed.

#### Scenario: Successful drain while matching
- **WHEN** a predicate matches multiple consecutive elements in the queue
- **THEN** all matching elements are removed and the count of removed elements is returned

#### Scenario: Drain while with early rejection
- **WHEN** a predicate returns false for the first element after a match
- **THEN** only the matching prefix is removed and the count of removed elements is returned

#### Scenario: Empty queue with drain
- **WHEN** the queue is empty and a predicate is provided
- **THEN** the method returns `0` without removing any elements