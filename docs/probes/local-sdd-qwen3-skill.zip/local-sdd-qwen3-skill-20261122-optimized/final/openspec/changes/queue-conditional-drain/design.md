# Design

## Context

The Queue class currently provides a basic FIFO API with methods for size, iteration, clear(), and drain(). This design extends the class to support conditional operations that allow dynamic filtering of elements based on runtime predicates.

## Goals / Non-Goals

**Goals:**
- Implement `dequeueIf(predicate)` to conditionally remove the head element based on a predicate function.
- Implement `drainWhile(predicate)` to remove the longest prefix of elements matching a predicate.
- Preserve all existing public FIFO API methods.
- Ensure the new methods are safe and do not modify the queue state when predicates return falsy values.

**Non-Goals:**
- Modify the underlying data structure of the queue (e.g., from array to linked list).
- Add new public APIs beyond the specified methods.
- Change the behavior of existing methods (e.g., size, iteration, clear(), drain()).

## Decisions

**1. Implementation of `dequeueIf(predicate)`**
- Choose to call the predicate on the head element only once, even if it is undefined.
- Return `true` if the predicate returns a truthy value, `false` otherwise.
- Return `false` immediately for empty queues without calling the predicate.
- Handle thrown errors by propagating them without removing the head element.

**Alternatives considered:**
- Call the predicate on the head element only if it is defined (avoiding undefined checks). This would be less safe for cases where undefined values are valid inputs.
- Return `false` for all cases where the predicate returns falsy, regardless of the head element's value. This would not provide the flexibility needed for conditional processing.

**2. Implementation of `drainWhile(predicate)`**
- Implement by repeatedly calling `dequeueIf(predicate)` until it returns `false`.
- Keep the first rejected element and everything after it.
- Propagate thrown errors from any `dequeueIf` call.

**Alternatives considered:**
- Implement a single pass through the queue to find the first non-matching element. This would be less efficient for long queues and could miss cases where elements are added after the initial scan.
- Return the count of elements removed without removing them. This would not provide the expected behavior of removing elements from the queue.

## Risks / Trade-offs

- [Performance impact] → The repeated calls to `dequeueIf` in `drainWhile` could lead to O(n²) performance in the worst case if the predicate is expensive to evaluate.
- [Error handling] → Thrown errors from predicates are propagated without removing the head, which could lead to inconsistent queue states in some cases.
- [Memory usage] → The queue may grow larger than necessary if elements are added after a `drainWhile` call, as the removed elements are not immediately freed.