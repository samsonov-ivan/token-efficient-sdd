# Proposal

## Why

Extend the Queue class to support conditional dequeue operations, enabling more flexible and safe handling of queue elements based on dynamic predicates. This improves the system's ability to process elements that meet specific criteria without requiring full iteration or blocking.

## What Changes

- Add a new `dequeueIf(predicate)` method to the Queue class that removes the head if the predicate returns truthy.
- Add a new `drainWhile(predicate)` method to remove the longest prefix matching the predicate and return the count removed.
- Preserve all existing public FIFO API methods: size, iteration, clear(), and drain().

## Capabilities

### New Capabilities
- `queue/conditional-drain`: Introduces conditional dequeue and drain operations for flexible queue processing.

## Impact

- Affected code: queue.mjs
- Affected tests: test/dequeue-if.test.mjs, test/drain-while.test.mjs
- No external dependencies or APIs changed.